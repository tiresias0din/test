Readme.txt
 
-------------------------------------------------------------------
This file outlines changes since the last release of MIBs.
 
It is very strongly recommended that you load and compile ALL of
the MIBs provided.
 
Please load the 'hpicfOid.mib' before loading the other specific
MIBs.  This is due to the fact that the 'hpicfOid.mib' is the
parent MIB to most of the HP device specific MIBs.
-------------------------------------------------------------------
		hpicfAuth.mib
		   -new objects
			hpSwitchRadiusTunnelPrivateGroupId
 
		hpicfSyslog.mib
		   -new objects
			hpicfSyslogPrefixString
 
		hpicfUsrAuth.mib
		   -new objects
			hpicfUsrAuthStationIdFormat
 
		hpicfSnmpUsm.mib
		   -new mib
             
                hpicfOid.mib
                  -new objects
                       hpicfSnmpUsm
